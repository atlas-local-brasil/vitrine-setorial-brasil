@echo off
start https://github.com/atlas-local-brasil/vitrine-setorial-brasil
