@echo off
start https://vitrine-setorial-brasil.onrender.com/
